package com.xinsuiev.saleskeyboard;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.provider.Settings;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.view.View;
import android.widget.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.text.InputType;

public class MainActivity extends Activity {
    private LinearLayout root;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(22), dp(18), dp(22));
        root.setBackgroundColor(Color.rgb(7,16,21));
        setContentView(root);

        TextView title = tv("新穗电改 XINSUI·EV", 24, true, Color.WHITE);
        TextView sub = tv("AI销售输入法 MVP", 16, false, Color.rgb(155,170,185));
        root.addView(title);
        root.addView(sub);

        addInfo("使用方式", "1. 点击“启用输入法”打开系统输入法设置；\n2. 勾选“新穗AI销售输入法”；\n3. 回到微信/小红书/企微聊天框，切换到本输入法；\n4. 复制客户消息，点“粘贴客户消息”，生成5条话术；\n5. 点选一条，直接插入当前输入框发送。");

        Button enable = btn("启用输入法");
        enable.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)));
        root.addView(enable);

        Button picker = btn("切换当前输入法");
        picker.setOnClickListener(v -> {
            InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null) imm.showInputMethodPicker();
        });
        root.addView(picker);

        addInfo("当前版本说明", "这是第一版可开发/可安装的安卓输入法工程。\n当前版本不读取微信聊天气泡，只读取销售主动复制/粘贴的客户消息，避免隐私和权限风险。\n后续可接入云端AI、门店知识库、套餐库、案例库和账号体系。");
    }

    private void addInfo(String h, String body){
        TextView head = tv(h, 18, true, Color.rgb(23,208,188));
        head.setPadding(0, dp(22), 0, dp(6));
        root.addView(head);
        TextView b = tv(body, 15, false, Color.rgb(225,235,245));
        b.setLineSpacing(4,1);
        b.setPadding(dp(12), dp(12), dp(12), dp(12));
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(Color.rgb(14,23,32));
        gd.setStroke(1, Color.argb(40,255,255,255));
        gd.setCornerRadius(dp(16));
        b.setBackground(gd);
        root.addView(b);
    }

    private TextView tv(String s, int sp, boolean bold, int color){
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextSize(sp);
        v.setTextColor(color);
        if (bold) v.setTypeface(Typeface.DEFAULT_BOLD);
        return v;
    }

    private Button btn(String s){
        Button b = new Button(this);
        b.setText(s);
        b.setTextColor(Color.rgb(5,16,20));
        b.setTypeface(Typeface.DEFAULT_BOLD);
        GradientDrawable gd = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{Color.rgb(23,208,188), Color.rgb(87,241,222)});
        gd.setCornerRadius(dp(14));
        b.setBackground(gd);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(52));
        lp.setMargins(0, dp(14), 0, 0);
        b.setLayoutParams(lp);
        return b;
    }

    private int dp(int v){ return (int)(v * getResources().getDisplayMetrics().density + .5f); }
}
