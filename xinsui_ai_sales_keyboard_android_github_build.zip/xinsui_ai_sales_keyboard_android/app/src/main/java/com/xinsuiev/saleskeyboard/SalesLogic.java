package com.xinsuiev.saleskeyboard;

import java.util.*;

public class SalesLogic {
    public static class Profile {
        public String customer = "客户";
        public String model = "";
        public String project = "车衣";
        public String budget = "";
        public String stage = "首次咨询";
        public String goal = "先回消息";
        public String objection = "暂未明确";
        public String focus = "还不明确";
    }

    public static String inferObjection(String text){
        if (text == null) return "暂未明确";
        if (text.matches(".*(贵|便宜|优惠|价格高|太高).*")) return "觉得贵";
        if (text.matches(".*(别家|对比|某家|其他店|报价).*")) return "对比别家";
        if (text.matches(".*(效果|好看|颜色|质感|高级).*")) return "担心效果";
        if (text.matches(".*(质保|品牌|靠谱吗|会不会|售后|施工).*")) return "担心品质/质保";
        if (text.matches(".*(考虑|回头|再说|先看看|了解一下|不急).*")) return "想再考虑";
        return "暂未明确";
    }

    public static String inferFocus(String text){
        if (text == null) return "还不明确";
        if (text.matches(".*(多少钱|价格|报价|预算|贵|便宜).*")) return "价格";
        if (text.matches(".*(效果|好看|颜值|颜色|质感|高级).*")) return "效果颜值";
        if (text.matches(".*(质保|品牌|靠谱|售后|施工).*")) return "品质与质保";
        return "还不明确";
    }

    public static String valuePoints(String project){
        if ("车衣".equals(project)) return "防护、抗污、防刮、增亮、保值和施工细节";
        if ("窗膜".equals(project)) return "隔热、清晰度、隐私、防晒和夜间视线";
        if ("改色".equals(project)) return "颜色质感、整体风格、耐看程度和施工收边";
        if ("双拼色".equals(project)) return "整体高级感、比例协调、原厂感和细节收边";
        if ("内饰升级".equals(project)) return "舒适度、实用性、质感和日常体验";
        return "效果、品质、施工和售后";
    }

    public static List<String> generate(Profile p, String latest, List<String> history, int seed){
        String lead = (p.customer == null || p.customer.trim().length()==0 || p.customer.equals("客户")) ? "" : p.customer + "，";
        String value = valuePoints(p.project);
        String full = (latest == null ? "" : latest) + "\n" + String.join("\n", history);
        String objection = "暂未明确".equals(p.objection) ? inferObjection(full) : p.objection;
        String focus = "还不明确".equals(p.focus) ? inferFocus(full) : p.focus;

        ArrayList<String[]> pool = new ArrayList<>();
        pool.add(new String[]{"先接住客户", lead+"您这个问题很正常，我先不急着只给您报一个死价格，因为"+p.model+"做"+p.project+"，差异主要在"+value+"。我可以先按您的预算给您分两档，这样您更容易判断哪一档最值得。"});
        pool.add(new String[]{"价值解释", lead+p.project+"不是简单“贴上去”就完事，真正影响体验的是材料、施工细节、后期质保和最终效果。我们更希望您这次做完后后面不用反复折腾，所以会把材料、施工和售后一起考虑进去。"});
        pool.add(new String[]{"化解比价", lead+"如果您现在在对比别家的价格，建议不要只看总价，可以一起看材料品牌、施工时间、边角收口、质保方式和售后处理。我们报价会把这些都算进去，主要是为了后面用得稳、少返工。"});
        pool.add(new String[]{"案例推进", lead+"单看文字和价格不够直观，我建议您先看一个同车型/同项目案例。如果这个效果是您想要的方向，我再按这个方向帮您匹配更合适的方案。"});
        pool.add(new String[]{"挖需求", lead+"我先确认一个关键点：您做"+p.project+"最主要是想解决价格、效果、保护、隔热，还是质保放心？这个确认清楚后，我给您的方案会更准，也能避免您花冤枉钱。"});
        pool.add(new String[]{"分层报价", lead+"我建议这样看：基础方案适合先解决核心需求；中间档更适合想要效果和稳定性都兼顾；高阶方案适合想一步到位的客户。您可以先告诉我更偏哪一档，我再给您细化。"});
        pool.add(new String[]{"邀约到店", lead+"线上我可以先帮您把方向收窄，但最终颜色、质感和施工细节，建议您到店看样会更准。您方便的话，我可以先帮您预留一个到店时间，现场确认会更稳。"});
        pool.add(new String[]{"处理犹豫", lead+"您可以先不用急着定，我建议您先看两个东西：同车型案例和方案差异。看完您基本就能判断这个钱值不值得花。如果方向合适，我们再聊具体时间。"});
        pool.add(new String[]{"专业背书", lead+p.model+"这类新能源车做"+p.project+"，我更建议按“最终效果+后期稳定性”来选。我们会重点看施工环境、师傅经验、边角细节和售后质保，这些才决定做完后是否耐看、省心。"});
        pool.add(new String[]{"促进行动", lead+"如果您这个方向基本确定，我建议先把方案和档期锁一下。到店后我们再根据实车状态确认最终细节，这样既不耽误时间，也能避免临时没有档期。"});

        ArrayList<String[]> prioritized = new ArrayList<>();
        if ("觉得贵".equals(objection) || "价格".equals(focus)) {
            add(prioritized, pool, 2,5,1,0,7);
        } else if ("对比别家".equals(objection)) {
            add(prioritized, pool, 2,1,5,3,6);
        } else if ("担心效果".equals(objection) || "效果颜值".equals(focus)) {
            add(prioritized, pool, 3,8,1,6,7);
        } else if ("担心品质/质保".equals(objection) || "品质与质保".equals(focus)) {
            add(prioritized, pool, 8,1,2,5,3);
        } else if ("促预约到店".equals(p.goal)) {
            add(prioritized, pool, 6,9,3,1,5);
        } else if ("挖需求".equals(p.goal)) {
            add(prioritized, pool, 4,0,3,5,1);
        } else {
            prioritized.addAll(pool);
        }
        for(String[] it: pool) if(!containsTitle(prioritized,it[0])) prioritized.add(it);

        List<String> out = new ArrayList<>();
        int offset = seed % prioritized.size();
        for(int i=0;i<5;i++){
            String[] item = prioritized.get((offset+i)%prioritized.size());
            out.add((i+1)+"、【"+item[0]+"】\n"+item[1]);
        }
        return out;
    }

    private static void add(ArrayList<String[]> target, ArrayList<String[]> pool, int... idx){
        for(int i: idx) target.add(pool.get(i));
    }
    private static boolean containsTitle(ArrayList<String[]> list, String title){
        for(String[] x:list) if(x[0].equals(title)) return true;
        return false;
    }
}
