package com.xinsuiev.saleskeyboard;

import android.inputmethodservice.InputMethodService;
import android.view.View;
import android.view.Gravity;
import android.view.inputmethod.InputConnection;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.widget.*;
import android.text.InputType;

import java.util.*;

public class SalesKeyboardService extends InputMethodService {
    private LinearLayout root;
    private EditText customerEt, modelEt, budgetEt, latestEt;
    private Spinner projectSp, goalSp, stageSp;
    private LinearLayout repliesBox, historyBox;
    private ArrayList<String> history = new ArrayList<>();
    private int seed = 0;

    private final String[] projects = {"车衣","窗膜","改色","双拼色","内饰升级","综合升级"};
    private final String[] goals = {"先回消息","挖需求","解释价值","化解比价","发案例推进","促预约到店","促成交收订金"};
    private final String[] stages = {"首次咨询","已发报价","对比中","高意向","已预约前"};

    @Override
    public View onCreateInputView() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(10), dp(8), dp(10), dp(10));
        root.setBackgroundColor(Color.rgb(7,16,21));

        ScrollView scroll = new ScrollView(this);
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(wrap);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, dp(430)));

        LinearLayout top = row();
        TextView title = tv("新穗AI销售输入法", 16, true, Color.WHITE);
        TextView tag = pill("XINSUI·EV");
        top.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        top.addView(tag);
        wrap.addView(top);

        TextView hint = tv("复制客户消息 → 粘贴 → 生成5条话术 → 点选插入当前聊天框", 12, false, Color.rgb(145,165,180));
        hint.setPadding(0, dp(4), 0, dp(8));
        wrap.addView(hint);

        LinearLayout r1 = row();
        customerEt = input("客户名", false);
        modelEt = input("车型，如理想L8", false);
        r1.addView(customerEt, new LinearLayout.LayoutParams(0, dp(46), 1));
        r1.addView(modelEt, new LinearLayout.LayoutParams(0, dp(46), 1));
        wrap.addView(r1);

        LinearLayout r2 = row();
        projectSp = spinner(projects);
        goalSp = spinner(goals);
        r2.addView(projectSp, new LinearLayout.LayoutParams(0, dp(46), 1));
        r2.addView(goalSp, new LinearLayout.LayoutParams(0, dp(46), 1));
        wrap.addView(r2);

        LinearLayout r3 = row();
        budgetEt = input("预算，如5000左右", false);
        stageSp = spinner(stages);
        r3.addView(budgetEt, new LinearLayout.LayoutParams(0, dp(46), 1));
        r3.addView(stageSp, new LinearLayout.LayoutParams(0, dp(46), 1));
        wrap.addView(r3);

        latestEt = input("粘贴客户最新一句话", true);
        wrap.addView(latestEt, new LinearLayout.LayoutParams(-1, dp(86)));

        LinearLayout buttons = row();
        Button paste = btn("粘贴客户消息");
        paste.setOnClickListener(v -> pasteFromClipboard());
        Button gen = btn("生成5条");
        gen.setOnClickListener(v -> generate(false));
        Button regen = btn("换5条");
        regen.setOnClickListener(v -> generate(true));
        buttons.addView(paste, new LinearLayout.LayoutParams(0, dp(46), 1));
        buttons.addView(gen, new LinearLayout.LayoutParams(0, dp(46), 1));
        buttons.addView(regen, new LinearLayout.LayoutParams(0, dp(46), 1));
        wrap.addView(buttons);

        LinearLayout intentRow = row();
        String[] quick = {"嫌贵","比价","问价格","发案例","约到店"};
        for(String q: quick){
            Button b = smallBtn(q);
            b.setOnClickListener(v -> {
                latestEt.append(latestEt.getText().length()>0 ? "\n客户关注："+q : "客户关注："+q);
                generate(false);
            });
            intentRow.addView(b, new LinearLayout.LayoutParams(0, dp(38), 1));
        }
        wrap.addView(intentRow);

        TextView lab = tv("可选销售回复", 14, true, Color.rgb(23,208,188));
        lab.setPadding(0, dp(10), 0, dp(6));
        wrap.addView(lab);

        repliesBox = new LinearLayout(this);
        repliesBox.setOrientation(LinearLayout.VERTICAL);
        wrap.addView(repliesBox);

        TextView histLab = tv("本轮对话记录", 14, true, Color.rgb(211,174,108));
        histLab.setPadding(0, dp(12), 0, dp(6));
        wrap.addView(histLab);

        historyBox = new LinearLayout(this);
        historyBox.setOrientation(LinearLayout.VERTICAL);
        wrap.addView(historyBox);

        Button clear = smallBtn("清空本轮对话");
        clear.setOnClickListener(v -> {
            history.clear();
            renderHistory();
            toast("已清空");
        });
        wrap.addView(clear, new LinearLayout.LayoutParams(-1, dp(40)));

        renderHistory();
        return root;
    }

    private void pasteFromClipboard(){
        ClipboardManager cm = (ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
        if(cm != null && cm.hasPrimaryClip()){
            ClipData data = cm.getPrimaryClip();
            if(data != null && data.getItemCount()>0){
                CharSequence cs = data.getItemAt(0).coerceToText(this);
                if(cs != null) {
                    latestEt.setText(cs.toString());
                    latestEt.setSelection(latestEt.length());
                    toast("已粘贴客户消息");
                }
            }
        } else toast("剪贴板为空");
    }

    private void generate(boolean regen){
        String latest = latestEt.getText().toString().trim();
        if(latest.length()==0 && !regen){
            toast("请先粘贴客户消息");
            return;
        }
        if(regen) seed += 5;
        else {
            if(latest.length()>0) {
                history.add("客户："+latest);
                latestEt.setText("");
            }
        }

        SalesLogic.Profile p = new SalesLogic.Profile();
        p.customer = customerEt.getText().toString().trim();
        if(p.customer.length()==0) p.customer = "客户";
        p.model = modelEt.getText().toString().trim();
        p.project = projectSp.getSelectedItem().toString();
        p.budget = budgetEt.getText().toString().trim();
        p.goal = goalSp.getSelectedItem().toString();
        p.stage = stageSp.getSelectedItem().toString();
        String context = latest.length()>0 ? latest : (history.size()>0 ? history.get(history.size()-1) : "");
        p.objection = SalesLogic.inferObjection(context);
        p.focus = SalesLogic.inferFocus(context);

        List<String> replies = SalesLogic.generate(p, context, history, seed);
        renderReplies(replies);
        renderHistory();
    }

    private void renderReplies(List<String> replies){
        repliesBox.removeAllViews();
        for(String reply: replies){
            TextView card = tv(reply, 14, false, Color.rgb(235,245,250));
            card.setPadding(dp(10), dp(10), dp(10), dp(10));
            card.setBackground(cardBg(false));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.setMargins(0, 0, 0, dp(8));
            repliesBox.addView(card, lp);
            card.setOnClickListener(v -> {
                String text = stripIndex(((TextView)v).getText().toString());
                commitText(text);
                history.add("销售："+text);
                renderHistory();
                toast("已插入输入框");
            });
        }
    }

    private String stripIndex(String s){
        return s.replaceFirst("^\\d+、【[^】]+】\\n", "").trim();
    }

    private void commitText(String s){
        InputConnection ic = getCurrentInputConnection();
        if(ic != null) ic.commitText(s, 1);
    }

    private void renderHistory(){
        if(historyBox == null) return;
        historyBox.removeAllViews();
        if(history.isEmpty()){
            TextView empty = tv("暂无对话记录", 12, false, Color.rgb(125,145,160));
            empty.setPadding(dp(8), dp(8), dp(8), dp(8));
            historyBox.addView(empty);
            return;
        }
        int start = Math.max(0, history.size()-6);
        for(int i=start;i<history.size();i++){
            String h = history.get(i);
            TextView v = tv(h, 12, false, h.startsWith("客户")?Color.WHITE:Color.rgb(190,255,248));
            v.setPadding(dp(8), dp(6), dp(8), dp(6));
            v.setBackground(cardBg(h.startsWith("销售")));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.setMargins(0,0,0,dp(5));
            historyBox.addView(v, lp);
        }
    }

    private LinearLayout row(){
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(0,0,0,dp(6));
        return r;
    }

    private EditText input(String hint, boolean multi){
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(Color.rgb(120,140,155));
        e.setTextColor(Color.WHITE);
        e.setTextSize(13);
        e.setPadding(dp(10),0,dp(10),0);
        e.setSingleLine(!multi);
        if(multi){
            e.setMinLines(2);
            e.setGravity(Gravity.TOP|Gravity.START);
            e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
            e.setPadding(dp(10),dp(8),dp(10),dp(8));
        }
        e.setBackground(cardBg(false));
        return e;
    }

    private Spinner spinner(String[] arr){
        Spinner s = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, arr);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        s.setAdapter(adapter);
        s.setBackground(cardBg(false));
        return s;
    }

    private Button btn(String s){
        Button b = new Button(this);
        b.setText(s);
        b.setTextSize(12);
        b.setTextColor(Color.rgb(5,16,20));
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setBackground(brandBg());
        return b;
    }

    private Button smallBtn(String s){
        Button b = new Button(this);
        b.setText(s);
        b.setTextSize(11);
        b.setTextColor(Color.WHITE);
        b.setBackground(cardBg(false));
        return b;
    }

    private TextView pill(String s){
        TextView v = tv(s, 11, true, Color.rgb(185,255,248));
        v.setPadding(dp(8), dp(4), dp(8), dp(4));
        v.setBackground(cardBg(true));
        return v;
    }

    private TextView tv(String s, int sp, boolean bold, int color){
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextSize(sp);
        v.setTextColor(color);
        if(bold) v.setTypeface(Typeface.DEFAULT_BOLD);
        return v;
    }

    private GradientDrawable cardBg(boolean accent){
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(accent ? Color.argb(42,23,208,188) : Color.rgb(13,24,33));
        gd.setStroke(1, accent ? Color.argb(80,23,208,188) : Color.argb(40,255,255,255));
        gd.setCornerRadius(dp(12));
        return gd;
    }

    private GradientDrawable brandBg(){
        GradientDrawable gd = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{Color.rgb(23,208,188), Color.rgb(87,241,222)});
        gd.setCornerRadius(dp(12));
        return gd;
    }

    private void toast(String s){ Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }
    private int dp(int v){ return (int)(v * getResources().getDisplayMetrics().density + .5f); }
}
