# 只有安卓手机时，如何在线生成 APK

> 安卓 APK 不能不签名安装；Debug APK 会自动带调试签名，可以直接安装测试。

## 方法：用 GitHub Actions 在线打包

1. 用手机浏览器打开 GitHub，新建一个仓库，例如 `xinsui-sales-keyboard`。
2. 把本工程 ZIP 解压后的所有文件上传到仓库根目录。
3. 进入仓库的 **Actions** 页面。
4. 选择 **Build Debug APK**。
5. 点 **Run workflow**。
6. 等待 3-8 分钟。
7. 构建完成后，在页面底部 **Artifacts** 下载 `xinsui-ai-sales-keyboard-debug-apk`。
8. 解压后得到 `app-debug.apk`，发到手机并安装。
9. 安装后：系统设置 → 输入法 → 启用「新穗AI销售输入法」。

## 注意
- 这是 Debug 签名测试版，不适合公开发布。
- 首次安装需要允许“安装未知来源应用”。
- 输入法属于敏感权限，手机会有安全提醒，测试时属于正常现象。
